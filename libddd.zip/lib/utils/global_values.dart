import 'package:flutter/widgets.dart';

class GlobalValues {
  //esta variable debe cambiar la raiz y , por lo tanto, el amterial, por lo tannto
  //debe de recosntruirlo
 static  ValueNotifier themeMode = ValueNotifier(1);
}

//los biulder regresan un widget